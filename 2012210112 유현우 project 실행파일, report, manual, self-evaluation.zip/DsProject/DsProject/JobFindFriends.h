#pragma once

void ProcFindFriends();
