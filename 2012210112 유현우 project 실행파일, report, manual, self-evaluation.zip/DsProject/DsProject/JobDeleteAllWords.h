#pragma once

void ProcDeleteAllWords();
