#pragma once

void ProcTopMostTweetWord();
