#pragma once

void ProcFindSCC();
