#pragma once

void ProcStatistics();
