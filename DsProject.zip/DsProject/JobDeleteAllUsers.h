#pragma once

void ProcDeleteAllUsers();
